from django import forms
from django.contrib.auth.models import User
from Dashboardapp.models import UserProfileInfo

class UserForm(forms.ModelForm):
    #password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'input-div pass'}))
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta:
        model = User
        fields = ['username','email','password']
        # widgets = {
        #     'username' : forms.TextInput(attrs={'class':'input-div.one'}),
        #     'email': forms.EmailInput(attrs={'class':'input-div email'}),
        #     'password' : forms.PasswordInput(attrs={'class':'input-div pass'}),
        # }

class UserProfileInfoForm(forms.ModelForm):
    class Meta():
        model = UserProfileInfo
        fields = ('portfolio_site','profile_pic')
