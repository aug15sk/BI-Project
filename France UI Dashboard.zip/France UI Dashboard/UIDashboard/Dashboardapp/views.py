from django.shortcuts import render, get_object_or_404
#for sign in and storing user info
from Dashboardapp.forms import UserForm,UserProfileInfoForm


#For Login and logout
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
#from django.core.urlresolvers import reverse
from django.urls import reverse
from django.contrib.auth.decorators import login_required #decorators for login page
# Create your views here.
import sqlite3

# Create your views here.
def daily_name(request,eid=None):
    db = sqlite3.connect('Processlog.db')
    cursortoday = db.cursor()
    cursortoday.execute("SELECT * from ProjectDetails WHERE Run_type in  ('WEEKLY', 'MONTHLY') and nextrundate not in ('On demand') and date(nextrundate) =  date('now')")
    daily_update = [row for row in cursortoday.fetchall()]
    date_dict = {
    'Projects':daily_update
    }
    print(date_dict)
    db.close()
    return render(request,'Dashboardapp/indexdaily.html',date_dict)
    # return HttpResponse("daily update is working")

def Projects(request):
    db = sqlite3.connect('Processlog.sqlite3')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Projects")
    webpages_list = [row for row in cursor.fetchall()]
    date_dict = {'Projects':webpages_list}
    print(date_dict)
    db.close()
    #return render(request,'UIDashboard/index.html',context=date_dict)
    #return render(request,'UIDashboard/index.html',{'webdata':webpages_list})
    return render(request,'Dashboardapp/index1.html',date_dict)
def execution_name(request,eid=None, id=None):
    # return HttpResponse("The execution id to be loaded is")db = sqlite3.connect('Processlog.db')
    db = sqlite3.connect('Processlog.db')
    cursor = db.cursor()
    query='''select A.Execution_id,A.Success_Flag ,B.*,c.Execution_Step_name from Executions as A INNER JOIN Executable_Statistics as B on A.Execution_id=B.Execution_id INNER join Project_Executables as C on C.Executable_ID=B.Executable_ID WHERE A.Execution_id="{}"'''.format(eid)
    cursor.execute(query)

    webpages_list = [row for row in cursor.fetchall()]


    date_dict = {'Projects':webpages_list}
    print(date_dict)
    db.close()
    return render(request,'Dashboardapp/indexexec.html',date_dict)

def project_name(request,id=None):
    # return HttpResponse("select * from PRO_UPDATED where Project_name= "+id)
    print("select * from PRO_UPDATED where Project_name="+id)
    db = sqlite3.connect('Processlog.db')
    cursor = db.cursor()
    query='''select PRO_UPDATED.Project_ID,Executions.* from PRO_UPDATED INNER JOIN Executions on PRO_UPDATED.Project_ID=Executions.Project_ID where Project_name="{}"'''.format(id)
    cursor.execute(query)

    webpages_list = [row for row in cursor.fetchall()]
    date_dict = {'Projects':webpages_list}
    print(date_dict)
    db.close()
    return render(request,'Dashboardapp/indexpro.html',date_dict)



def index(request):
    return render(request,'Dashboardapp/index.html')

def index1(request):
    return render(request,'Dashboardapp/index1.html',{})

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def register(request):
    registered = False

    if request.method == 'POST':
            user_form = UserForm(data=request.POST)
            profile_form = UserProfileInfoForm(data=request.POST)
# if user_form.is_valid() and profile_form.is_valid():change has been made for 'and' to 'or'
            if user_form.is_valid() and profile_form.is_valid():
                user = user_form.save()
                user.set_password(user.password)
                user.save()

                profile = profile_form.save(commit=False)
                profile.user = user
                profile.save()
                registered = True
                #if 'profile_pic' in request.FILES:
                    #profile.profile_pic = request.FILES['profile_pic']
                    #profile.save()

                    #registered = True


                #else:
                    #print(user_form.errors,profile_form.errors)
    else:
            user_form = UserForm()
            profile_form = UserProfileInfoForm()

    return render(request,'Dashboardapp/registration.html',
                                                        {
                                                        'user_form':user_form,
                                                        'profile_form':profile_form,
                                                        'registered':registered
                                                        })

# return HttpResponse("select * from PRO_UPDATED where Project_name= "+id)
def formView(request):
   if request.session.has_key('username'):
      username = request.session['username']
      return HttpResponse("the username is " + username)

def user_login(request):

    if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')
            request.session['username'] = username
            #this line will authenticate user in 1 statement
            user = authenticate(username=username, password=password)

            if user:
                if user.is_active:

                    login(request,user)

                    # return HttpResponseRedirect(reverse('index'))

                    db = sqlite3.connect('Processlog.db')
                    cursor = db.cursor()
                    cursor.execute("SELECT * FROM PRO_UPDATED")
                    webpages_list = [row for row in cursor.fetchall()]
                    cursorlive = db.cursor()
                    cursorlive.execute("SELECT count(*) from ProjectDetails WHERE Run_type in  ('WEEKLY', 'MONTHLY') and nextrundate not in ('On demand') and strftime('%W',date(nextrundate)) =  strftime('%W','now')")
                    weekly_update = [row for row in cursorlive.fetchall()]
                    cursortoday = db.cursor()
                    cursortoday.execute("SELECT count(*) from ProjectDetails WHERE Run_type in  ('WEEKLY', 'MONTHLY') and nextrundate not in ('On demand') and date(nextrundate) =  date('now')")
                    daily_update = [row for row in cursortoday.fetchall()]
                    cursorsuccess = db.cursor()
                    cursorsuccess.execute("select count(*) from  (select A.Project_ID from Projects as A INNER JOIN Project_Executables as B on A.Project_ID=B.Project_ID INNER join Executions as E on A.Project_ID = E.Project_ID WHERE E.Success_Flag = 'Y' and strftime('%W',date(Execution_Start_time)) =  strftime('%W','now')GROUP by A.Project_ID ) a")
                    success_update = [row for row in cursorsuccess.fetchall()]
                    cursorfailed = db.cursor()
                    cursorfailed.execute("select count(*) from  (select A.Project_ID from Projects as A INNER JOIN Project_Executables as B on A.Project_ID=B.Project_ID INNER join Executions as E on A.Project_ID = E.Project_ID WHERE E.Success_Flag = 'N' and strftime('%W',date(Execution_Start_time)) =  strftime('%W','now')GROUP by A.Project_ID ) a ")
                    failed_update = [row for row in cursorfailed.fetchall()]
                    date_dict = {'Projects':webpages_list,
                    'Week':weekly_update,
                    'Daily':daily_update,
                    'success':success_update,
                    'failed': failed_update
                    }
                    print(date_dict)
                    db.close()
                    #return render(request,'UIDashboard/index.html',context=date_dict)
                    #return render(request,'UIDashboard/index.html',{'webdata':webpages_list})
                    return render(request,'Dashboardapp/index1.html',date_dict)
                    #return render(request,'Dashboardapp/index1.html',date_dict )
                 # return render(request, 'blog/post_list.html', {'posts': posts})
                    #return HttpResponse("Active")
     #            else:
     #                return HttpResponse("Account not Active")
            else:
                print("Looged in and out")
                print("Username: {} and password: {}".format(username,password))
                return HttpResponse("Invalid login details")
     # else:

     #        return render(request,'Dashboardapp/login.html',{})
