from django.shortcuts import render, get_object_or_404
#for sign in and storing user info
from Dashboardapp.forms import UserForm,UserProfileInfoForm


#For Login and logout
from django.contrib.auth import authenticate,login,logout
from django.http import HttpResponseRedirect,HttpResponse
#from django.core.urlresolvers import reverse
from django.urls import reverse
from django.contrib.auth.decorators import login_required #decorators for login page
# Create your views here.
import sqlite3

# Create your views here.
def Projects(request):
    db = sqlite3.connect('Processlog.sqlite3')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Projects")
    webpages_list = [row for row in cursor.fetchall()]
    date_dict = {'Projects':webpages_list}
    print(date_dict)
    db.close()
    #return render(request,'UIDashboard/index.html',context=date_dict)
    #return render(request,'UIDashboard/index.html',{'webdata':webpages_list})
    return render(request,'Dashboardapp/index1.html',date_dict)
def execution_name(request,eid=None, id=None):
    return HttpResponse("The execution id to be loaded is")

def project_name(request,id=None):
    # return HttpResponse("select * from PRO_UPDATED where Project_name= "+id)
    print("select * from PRO_UPDATED where Project_name="+id)
    db = sqlite3.connect('Processlog.db')
    cursor = db.cursor()
    query='''select PRO_UPDATED.Project_ID,Executions.* from PRO_UPDATED INNER JOIN Executions on PRO_UPDATED.Project_ID=Executions.Project_ID where Project_name="{}"'''.format(id)
    cursor.execute(query)

    webpages_list = [row for row in cursor.fetchall()]
    date_dict = {'Projects':webpages_list}
    print(date_dict)
    db.close()
    return render(request,'Dashboardapp/indexpro.html',date_dict)



def index(request):
    return render(request,'Dashboardapp/index.html')

def index1(request):
    return render(request,'Dashboardapp/index1.html',{})

@login_required
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))

def register(request):
    registered = False

    if request.method == 'POST':
            user_form = UserForm(data=request.POST)
            profile_form = UserProfileInfoForm(data=request.POST)
# if user_form.is_valid() and profile_form.is_valid():change has been made for 'and' to 'or'
            if user_form.is_valid() and profile_form.is_valid():
                user = user_form.save()
                user.set_password(user.password)
                user.save()

                profile = profile_form.save(commit=False)
                profile.user = user
                profile.save()
                registered = True
                #if 'profile_pic' in request.FILES:
                    #profile.profile_pic = request.FILES['profile_pic']
                    #profile.save()

                    #registered = True


                #else:
                    #print(user_form.errors,profile_form.errors)
    else:
            user_form = UserForm()
            profile_form = UserProfileInfoForm()

    return render(request,'Dashboardapp/registration.html',
                                                        {
                                                        'user_form':user_form,
                                                        'profile_form':profile_form,
                                                        'registered':registered
                                                        })


def user_login(request):

     # if request.method == 'POST':
     #        username = request.POST.get('username')
     #        password = request.POST.get('password')
     #
     #        #this line will authenticate user in 1 statement
     #        user = authenticate(username=username, password=password)
     #
     #        if user:
     #            if user.is_active:
                    # login(request,user)
                    #return HttpResponseRedirect(reverse('index'))

                    db = sqlite3.connect('Processlog.db')
                    cursor = db.cursor()
                    cursor.execute("SELECT * FROM PRO_UPDATED")
                    webpages_list = [row for row in cursor.fetchall()]
                    date_dict = {'Projects':webpages_list}
                    print(date_dict)
                    db.close()
                    #return render(request,'UIDashboard/index.html',context=date_dict)
                    #return render(request,'UIDashboard/index.html',{'webdata':webpages_list})
                    return render(request,'Dashboardapp/index1.html',date_dict)
                    #return render(request,'Dashboardapp/index1.html',date_dict )
                 # return render(request, 'blog/post_list.html', {'posts': posts})
                    #return HttpResponse("Active")
     #            else:
     #                return HttpResponse("Account not Active")
     #        else:
     #            print("Looged in and out")
     #            print("Username: {} and password: {}".format(username,password))
     #            return HttpResponse("Invalid login details")
     # else:
     #        return render(request,'Dashboardapp/login.html',{})
