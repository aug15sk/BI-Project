from django.apps import AppConfig


class DashboardappConfig(AppConfig):
    name = 'Dashboardapp'
