
from django.shortcuts import render
import sqlite3

# Create your views here.
def Projects1(request):
    db = sqlite3.connect('Processlog.sqlite3')
    cursor = db.cursor()
    cursor.execute("SELECT * FROM Projects")
    #for i in range(0,2):
    webpages_list = [row for row in cursor.fetchall()]
    date_dict = {'Projects':webpages_list}
    #print(date_dict)
    db.close()
    return render(request,'UIDashboard/index.html',context=date_dict)
    #return render(request,'UIDashboard/index.html',{'webdata':webpages_list})
    #return render(request,'UIDashboard/index.html',date_dict)

def index(request):
    return render(request,'Dashboardapp/index.html')
