from django.conf.urls import url
from Dashboardapp import views

app_name = 'Dashboardapp'

urlpatterns = [
url(r'^register/$',views.register,name='register'),
url(r'^user_login/$',views.user_login,name='user_login'),
url(r'^user_login/(?P<id>.*)/$',views.project_name),
url(r'^user_login/daily/(?P<eid>.*)$',views.daily_name),
url(r'^user_login/(?P<id>.*)/(?P<eid>.*)$',views.execution_name),

]
